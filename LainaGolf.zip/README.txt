LainaGolf 3.0 - instalacja

Wymagania:
- Paper dla Minecraft Java Edition 26.2 (sprawdzono na buildzie 111)
- Java 25
- Nie jest wymagany dodatkowy plugin Chaos Cubed ani Sulfur Cubes.

Instalacja:
1. Zatrzymaj serwer.
2. Skopiuj LainaGolf-3.0.jar do folderu plugins serwera.
3. Uruchom serwer, aby utworzył plugins/LainaGolf/config.yml.
4. W config.yml ustaw nazwy istniejących, załadowanych światów oraz współrzędne mapy.
   Domyślna konfiguracja używa świata world_adventure, który może nie istnieć na Twoim serwerze.
5. Wykonaj pełny restart serwera.
6. Sprawdź /plugins - LainaGolf powinien być aktywny (zielony).

Komenda:
/minigolf join <mapa> <gracz>

Komenda jest dostępna dla konsoli oraz operatorów serwera.

